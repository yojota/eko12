﻿**************************************************
Comunicaciones ofuscadas	

El ganador del reto será quien pueda descubrir qué es lo que está realizando el archivo. El flag lo podrán encontrar en la información de conexión de los servicios de transferencia de archivos.

Pass: infected