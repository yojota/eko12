**************************************************
Buscando informaci�n oculta

El archivo es un video, contiene mas informacion de a la que deberia. Para obtener el flag, deberas encontrar la forma de extraer la informacion oculta en el archivo.

Suerte!.