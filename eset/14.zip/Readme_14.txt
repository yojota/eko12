﻿**************************************************
Este es el desafío bonus con el que podrás conseguir puntos adicionales para sumar por el premio final

A partir del archivo de Word debes buscar las pistas que están dentro del archivo y que te van a llevar a resolver el reto. Una vez que obtengas la clave nos entregas la respuesta y ganas los puntos adicionales.

Pass: infected

