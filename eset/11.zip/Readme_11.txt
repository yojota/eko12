
La bandera de este nivel la obtienes a partir de la siguiente cadena:

0000000000000000001d07076713514505

Si requieres informaci�n adicional, recurre a la bandera obtenida durante tu recorrido por Argentina.