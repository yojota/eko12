**************************************************
Buscando informaci�n oculta

El arte de combinar los sonidos en una secuencia temporal atendiendo a las leyes de la armon�a puede ser utilizada para esconder informaci�n. Deber�s encontrar el modo de extraerla.
�xitos!

