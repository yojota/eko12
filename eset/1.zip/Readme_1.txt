**************************************************
Buscando informaci�n oculta

Estos archivos contiene mas informacion de la que se puede ver a simple vista. Para obtener el flag, deberas investigar la forma de extraerla.

Exitos!

