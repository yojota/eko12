**************************************************
Find the *flag* 

A partir de la captura de red, ¿podrías encontrar el flag pirata y resolver el reto?