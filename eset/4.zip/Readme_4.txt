﻿**************************************************
Caos de pings y mi perro dinamita

En el archivo adjunto hay una captura de red de solo paquetes ICMP... pero hay algunos que tienen información diferente a la habitual, podrías encontrar estos paquetes diferentes y reconstruir el mensaje oculto enviado?